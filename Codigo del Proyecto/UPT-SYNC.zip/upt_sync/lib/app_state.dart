import 'package:flutter/material.dart';
import '/backend/api_requests/api_manager.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';
import 'dart:convert';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {
    prefs = await SharedPreferences.getInstance();
    _safeInit(() {
      _userName = prefs.getString('ff_userName') ?? _userName;
    });
    _safeInit(() {
      _userEmail = prefs.getString('ff_userEmail') ?? _userEmail;
    });
  }

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  late SharedPreferences prefs;

  String _authToken = '';
  String get authToken => _authToken;
  set authToken(String value) {
    _authToken = value;
  }

  String _userName = '';
  String get userName => _userName;
  set userName(String value) {
    _userName = value;
    prefs.setString('ff_userName', value);
  }

  String _userEmail = '';
  String get userEmail => _userEmail;
  set userEmail(String value) {
    _userEmail = value;
    prefs.setString('ff_userEmail', value);
  }

  String _codigo = '';
  String get codigo => _codigo;
  set codigo(String value) {
    _codigo = value;
  }

  String _clave = '';
  String get clave => _clave;
  set clave(String value) {
    _clave = value;
  }

  List<dynamic> _horarioList = [];
  List<dynamic> get horarioList => _horarioList;
  set horarioList(List<dynamic> value) {
    _horarioList = value;
  }

  void addToHorarioList(dynamic value) {
    horarioList.add(value);
  }

  void removeFromHorarioList(dynamic value) {
    horarioList.remove(value);
  }

  void removeAtIndexFromHorarioList(int index) {
    horarioList.removeAt(index);
  }

  void updateHorarioListAtIndex(
    int index,
    dynamic Function(dynamic) updateFn,
  ) {
    horarioList[index] = updateFn(_horarioList[index]);
  }

  void insertAtIndexInHorarioList(int index, dynamic value) {
    horarioList.insert(index, value);
  }

  List<dynamic> _justificacionesList = [];
  List<dynamic> get justificacionesList => _justificacionesList;
  set justificacionesList(List<dynamic> value) {
    _justificacionesList = value;
  }

  void addToJustificacionesList(dynamic value) {
    justificacionesList.add(value);
  }

  void removeFromJustificacionesList(dynamic value) {
    justificacionesList.remove(value);
  }

  void removeAtIndexFromJustificacionesList(int index) {
    justificacionesList.removeAt(index);
  }

  void updateJustificacionesListAtIndex(
    int index,
    dynamic Function(dynamic) updateFn,
  ) {
    justificacionesList[index] = updateFn(_justificacionesList[index]);
  }

  void insertAtIndexInJustificacionesList(int index, dynamic value) {
    justificacionesList.insert(index, value);
  }

  List<dynamic> _asistenciasList = [];
  List<dynamic> get asistenciasList => _asistenciasList;
  set asistenciasList(List<dynamic> value) {
    _asistenciasList = value;
  }

  void addToAsistenciasList(dynamic value) {
    asistenciasList.add(value);
  }

  void removeFromAsistenciasList(dynamic value) {
    asistenciasList.remove(value);
  }

  void removeAtIndexFromAsistenciasList(int index) {
    asistenciasList.removeAt(index);
  }

  void updateAsistenciasListAtIndex(
    int index,
    dynamic Function(dynamic) updateFn,
  ) {
    asistenciasList[index] = updateFn(_asistenciasList[index]);
  }

  void insertAtIndexInAsistenciasList(int index, dynamic value) {
    asistenciasList.insert(index, value);
  }
}

void _safeInit(Function() initializeField) {
  try {
    initializeField();
  } catch (_) {}
}

Future _safeInitAsync(Function() initializeField) async {
  try {
    await initializeField();
  } catch (_) {}
}
