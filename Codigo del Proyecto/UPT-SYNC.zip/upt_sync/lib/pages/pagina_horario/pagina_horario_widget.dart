import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import '/custom_code/widgets/index.dart' as custom_widgets;
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'pagina_horario_model.dart';
export 'pagina_horario_model.dart';

class PaginaHorarioWidget extends StatefulWidget {
  /// Diseña una página en FlutterFlow que tenga las siguientes secciones:
  ///
  /// Encabezado:
  /// Texto Superior:
  ///
  /// Título: "Horarios del Usuario".
  /// Subtítulo: "Código del Usuario: [userCode]" (Donde [userCode] es dinámico
  /// y se toma de la API).
  /// Estilo:
  /// Título: Fuente grande, bold, centrado.
  /// Subtítulo: Fuente mediana, centrado.
  /// Fondo del Encabezado:
  ///
  /// Un Container con un fondo de color azul claro o degradado.
  /// Lista de Cursos y Horarios:
  /// Diseño General:
  /// Usa un ListView para iterar sobre los cursos del usuario.
  ///
  /// Cada elemento de la lista debe tener un diseño limpio con los siguientes
  /// detalles:
  ///
  /// Nombre del Curso:
  ///
  /// Coloca el nombre del curso (name) en la parte superior.
  /// Estilo: Fuente grande, bold.
  /// Sección del Curso:
  ///
  /// Debajo del nombre, coloca el texto "Sección: [section]".
  /// Estilo: Fuente mediana, color gris.
  /// Horario del Curso:
  ///
  /// Coloca una lista de días y horarios dentro del curso. Cada día debe
  /// mostrarse en su propia línea con este formato:
  /// plaintext
  /// Copiar código
  /// Miércoles: 15:00 - 17:30
  /// Lunes: (Sin clases)
  /// Usa un Column dentro del ListView para iterar sobre los días de la semana
  /// (lunes, martes, etc.).
  const PaginaHorarioWidget({super.key});

  @override
  State<PaginaHorarioWidget> createState() => _PaginaHorarioWidgetState();
}

class _PaginaHorarioWidgetState extends State<PaginaHorarioWidget> {
  late PaginaHorarioModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => PaginaHorarioModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        body: Container(
          width: MediaQuery.sizeOf(context).width * 1.059,
          height: MediaQuery.sizeOf(context).height * 1.0,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFF1A237E), Color(0xFF3949AB)],
              stops: [0.0, 1.0],
              begin: AlignmentDirectional(0.0, -1.0),
              end: AlignmentDirectional(0, 1.0),
            ),
          ),
          child: Padding(
            padding: EdgeInsetsDirectional.fromSTEB(24.0, 24.0, 24.0, 24.0),
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: MediaQuery.sizeOf(context).width * 1.0,
                    height: 160.0,
                    child: Padding(
                      padding: EdgeInsetsDirectional.fromSTEB(
                          24.0, 24.0, 24.0, 24.0),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Text(
                            'Horarios del Usuario',
                            style: FlutterFlowTheme.of(context)
                                .headlineMedium
                                .override(
                                  fontFamily: 'Inter Tight',
                                  color: FlutterFlowTheme.of(context).info,
                                  letterSpacing: 0.0,
                                  fontWeight: FontWeight.bold,
                                ),
                          ),
                        ].divide(SizedBox(height: 8.0)),
                      ),
                    ),
                  ),
                  FFButtonWidget(
                    onPressed: () async {
                      context.pushNamed('PaginaPrincipal');
                    },
                    text: 'Regresar',
                    options: FFButtonOptions(
                      height: 40.0,
                      padding:
                          EdgeInsetsDirectional.fromSTEB(16.0, 0.0, 16.0, 0.0),
                      iconPadding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
                      color: FlutterFlowTheme.of(context).primary,
                      textStyle:
                          FlutterFlowTheme.of(context).titleSmall.override(
                                fontFamily: 'Inter Tight',
                                color: Colors.white,
                                letterSpacing: 0.0,
                              ),
                      elevation: 0.0,
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                  ),
                  Align(
                    alignment: AlignmentDirectional(0.0, 0.0),
                    child: FutureBuilder<ApiCallResponse>(
                      future: (_model.apiRequestCompleter ??=
                              Completer<ApiCallResponse>()
                                ..complete(ApiGroup.scheduleCall.call(
                                  authToken: FFAppState().authToken,
                                )))
                          .future,
                      builder: (context, snapshot) {
                        // Customize what your widget looks like when it's loading.
                        if (!snapshot.hasData) {
                          return Center(
                            child: SizedBox(
                              width: 50.0,
                              height: 50.0,
                              child: CircularProgressIndicator(
                                valueColor: AlwaysStoppedAnimation<Color>(
                                  FlutterFlowTheme.of(context).primary,
                                ),
                              ),
                            ),
                          );
                        }
                        final listViewScheduleResponse = snapshot.data!;

                        return Builder(
                          builder: (context) {
                            final listSchedule = ApiGroup.scheduleCall
                                    .schedule(
                                      listViewScheduleResponse.jsonBody,
                                    )
                                    ?.toList() ??
                                [];

                            return RefreshIndicator(
                              onRefresh: () async {
                                safeSetState(
                                    () => _model.apiRequestCompleter = null);
                                await _model.waitForApiRequestCompleted();
                              },
                              child: ListView.separated(
                                padding: EdgeInsets.zero,
                                shrinkWrap: true,
                                scrollDirection: Axis.vertical,
                                itemCount: listSchedule.length,
                                separatorBuilder: (_, __) =>
                                    SizedBox(height: 10.0),
                                itemBuilder: (context, listScheduleIndex) {
                                  final listScheduleItem =
                                      listSchedule[listScheduleIndex];
                                  return Container(
                                    width: double.infinity,
                                    height: 282.0,
                                    decoration: BoxDecoration(
                                      color: FlutterFlowTheme.of(context)
                                          .secondaryBackground,
                                      borderRadius: BorderRadius.only(
                                        bottomLeft: Radius.circular(12.0),
                                        bottomRight: Radius.circular(12.0),
                                        topLeft: Radius.circular(12.0),
                                        topRight: Radius.circular(12.0),
                                      ),
                                    ),
                                    child: Padding(
                                      padding: EdgeInsetsDirectional.fromSTEB(
                                          12.0, 0.0, 12.0, 0.0),
                                      child: Column(
                                        mainAxisSize: MainAxisSize.max,
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        children: [
                                          Text(
                                            getJsonField(
                                              listScheduleItem,
                                              r'''$.name''',
                                            ).toString().maybeHandleOverflow(
                                                  maxChars: 25,
                                                ),
                                            style: FlutterFlowTheme.of(context)
                                                .bodySmall
                                                .override(
                                                  fontFamily: 'Inter',
                                                  color: FlutterFlowTheme.of(
                                                          context)
                                                      .primaryText,
                                                  fontSize: 18.0,
                                                  letterSpacing: 0.0,
                                                  fontWeight: FontWeight.w600,
                                                ),
                                          ),
                                          Text(
                                            getJsonField(
                                              listScheduleItem,
                                              r'''$.code''',
                                            ).toString(),
                                            style: FlutterFlowTheme.of(context)
                                                .bodyMedium
                                                .override(
                                                  fontFamily: 'Inter',
                                                  fontSize: 14.0,
                                                  letterSpacing: 0.0,
                                                ),
                                          ),
                                          Text(
                                            getJsonField(
                                              listScheduleItem,
                                              r'''$.section''',
                                            ).toString(),
                                            style: FlutterFlowTheme.of(context)
                                                .bodyMedium
                                                .override(
                                                  fontFamily: 'Inter',
                                                  fontSize: 14.0,
                                                  letterSpacing: 0.0,
                                                ),
                                          ),
                                          Container(
                                            width: double.infinity,
                                            height: 200.0,
                                            child: custom_widgets
                                                .WeekScheduleWidget(
                                              width: double.infinity,
                                              height: 200.0,
                                              schedule: getJsonField(
                                                listScheduleItem,
                                                r'''$.schedule''',
                                              ),
                                            ),
                                          ),
                                        ].divide(SizedBox(height: 5.0)),
                                      ),
                                    ),
                                  );
                                },
                              ),
                            );
                          },
                        );
                      },
                    ),
                  ),
                ].divide(SizedBox(height: 24.0)),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
