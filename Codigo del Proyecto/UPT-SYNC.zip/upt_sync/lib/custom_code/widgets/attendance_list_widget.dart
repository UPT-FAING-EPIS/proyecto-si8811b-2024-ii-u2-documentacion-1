// Automatic FlutterFlow imports
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom widget code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

// Set your widget name, define your parameter, and then add the
// boilerplate code using the green button on the right!
import '/custom_code/widgets/index.dart';
import '/flutter_flow/custom_functions.dart';

class AttendanceListWidget extends StatefulWidget {
  const AttendanceListWidget({
    Key? key,
    this.width,
    this.height,
    required this.attendances,
  }) : super(key: key);

  final double? width;
  final double? height;
  final dynamic attendances; // Cambiado para aceptar JSON directamente

  @override
  _AttendanceListWidgetState createState() => _AttendanceListWidgetState();
}

class _AttendanceListWidgetState extends State<AttendanceListWidget> {
  List<dynamic> get attendancesList {
    if (widget.attendances is List) {
      return widget.attendances as List<dynamic>;
    }
    return [];
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: widget.width,
      height: widget.height,
      child: ListView.builder(
        padding: EdgeInsets.symmetric(vertical: 8),
        itemCount: attendancesList.length,
        itemBuilder: (context, index) {
          final attendance = attendancesList[index];
          final bool isPresent = attendance['estado'] == 'Asiste';

          return Container(
            margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  blurRadius: 4,
                  offset: Offset(0, 2),
                ),
              ],
            ),
            child: Column(
              children: [
                Container(
                  width: double.infinity,
                  padding: EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: isPresent
                        ? Color(0xFF4CAF50).withOpacity(0.1)
                        : Color(0xFFF44336).withOpacity(0.1),
                    borderRadius:
                        BorderRadius.vertical(top: Radius.circular(12)),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        attendance['fecha']?.toString() ?? '',
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily: 'Readex Pro',
                              color: isPresent
                                  ? Color(0xFF4CAF50)
                                  : Color(0xFFF44336),
                              fontWeight: FontWeight.w600,
                            ),
                      ),
                      Text(
                        attendance['dia']?.toString() ?? '',
                        style: FlutterFlowTheme.of(context).bodyMedium.override(
                              fontFamily: 'Readex Pro',
                              color: isPresent
                                  ? Color(0xFF4CAF50)
                                  : Color(0xFFF44336),
                            ),
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding: EdgeInsets.all(12),
                  child: Row(
                    children: [
                      Icon(
                        isPresent ? Icons.check_circle : Icons.cancel,
                        color:
                            isPresent ? Color(0xFF4CAF50) : Color(0xFFF44336),
                      ),
                      SizedBox(width: 8),
                      Text(
                        attendance['estado']?.toString() ?? '',
                        style: FlutterFlowTheme.of(context).titleSmall.override(
                              fontFamily: 'Readex Pro',
                              color: isPresent
                                  ? Color(0xFF4CAF50)
                                  : Color(0xFFF44336),
                            ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
