import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';

import '/flutter_flow/flutter_flow_util.dart';
import 'api_manager.dart';

export 'api_manager.dart' show ApiCallResponse;

const _kPrivateApiFunctionName = 'ffPrivateApiCall';

/// Start API Group Code

class ApiGroup {
  static String getBaseUrl({
    String? authToken = '',
  }) =>
      'http://52.225.232.58:3000';
  static Map<String, String> headers = {};
  static DefaultLoginCall defaultLoginCall = DefaultLoginCall();
  static DefaultUserCall defaultUserCall = DefaultUserCall();
  static SyncUserCall syncUserCall = SyncUserCall();
  static SyncUserScheduleCall syncUserScheduleCall = SyncUserScheduleCall();
  static SyncUserAttendanceCall syncUserAttendanceCall =
      SyncUserAttendanceCall();
  static ScheduleCall scheduleCall = ScheduleCall();
  static AttendanceCall attendanceCall = AttendanceCall();
  static AllJustificationCall allJustificationCall = AllJustificationCall();
  static JustificactionCall justificactionCall = JustificactionCall();
}

class DefaultLoginCall {
  Future<ApiCallResponse> call({
    String? email = '',
    String? password = '',
    String? authToken = '',
  }) async {
    final baseUrl = ApiGroup.getBaseUrl(
      authToken: authToken,
    );

    final ffApiRequestBody = '''
{
  "email": "${escapeStringForJson(email)}",
  "password": "${escapeStringForJson(password)}"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'Default Login',
      apiUrl: '${baseUrl}/api/v1/auth/login',
      callType: ApiCallType.POST,
      headers: {},
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class DefaultUserCall {
  Future<ApiCallResponse> call({
    String? authToken = '',
  }) async {
    final baseUrl = ApiGroup.getBaseUrl(
      authToken: authToken,
    );

    return ApiManager.instance.makeApiCall(
      callName: 'Default User',
      apiUrl: '${baseUrl}/api/v1/auth/user',
      callType: ApiCallType.GET,
      headers: {
        'Authorization': 'Bearer ${authToken}',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }

  String? email(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.email''',
      ));
  String? name(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.name''',
      ));
}

class SyncUserCall {
  Future<ApiCallResponse> call({
    String? codigo = '',
    String? contrasena = '',
    String? authToken = '',
  }) async {
    final baseUrl = ApiGroup.getBaseUrl(
      authToken: authToken,
    );

    final ffApiRequestBody = '''
{
  "codigo": "${escapeStringForJson(codigo)}",
  "contrasena": "${escapeStringForJson(contrasena)}"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'Sync User',
      apiUrl: '${baseUrl}/api/v1/sync/data',
      callType: ApiCallType.POST,
      headers: {
        'Authorization': 'Bearer ${authToken}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }

  String? message(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.message''',
      ));
}

class SyncUserScheduleCall {
  Future<ApiCallResponse> call({
    String? codigo = '',
    String? contrasena = '',
    String? authToken = '',
  }) async {
    final baseUrl = ApiGroup.getBaseUrl(
      authToken: authToken,
    );

    final ffApiRequestBody = '''
{
  "codigo": "${escapeStringForJson(codigo)}",
  "contrasena": "${escapeStringForJson(contrasena)}"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'Sync User Schedule',
      apiUrl: '${baseUrl}/api/v1/sync/schedule',
      callType: ApiCallType.POST,
      headers: {
        'Authorization': 'Bearer ${authToken}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }

  String? message(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.message''',
      ));
  List? scheduleData(dynamic response) => getJsonField(
        response,
        r'''$.scheduleData''',
        true,
      ) as List?;
  List<String>? code(dynamic response) => (getJsonField(
        response,
        r'''$.scheduleData[:].code''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  List<String>? name(dynamic response) => (getJsonField(
        response,
        r'''$.scheduleData[:].name''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  List<String>? section(dynamic response) => (getJsonField(
        response,
        r'''$.scheduleData[:].section''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  List? schedule(dynamic response) => getJsonField(
        response,
        r'''$.scheduleData[:].schedule''',
        true,
      ) as List?;
}

class SyncUserAttendanceCall {
  Future<ApiCallResponse> call({
    String? codigo = '',
    String? contrasena = '',
    String? authToken = '',
  }) async {
    final baseUrl = ApiGroup.getBaseUrl(
      authToken: authToken,
    );

    final ffApiRequestBody = '''
{
  "codigo": "${escapeStringForJson(codigo)}",
  "contrasena": "${escapeStringForJson(contrasena)}"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'Sync User Attendance',
      apiUrl: '${baseUrl}/api/v1/sync/attendance',
      callType: ApiCallType.POST,
      headers: {
        'Authorization': 'Bearer ${authToken}',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }

  String? message(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.message''',
      ));
  List? attendanceData(dynamic response) => getJsonField(
        response,
        r'''$.attendanceData''',
        true,
      ) as List?;
  List<String>? curso(dynamic response) => (getJsonField(
        response,
        r'''$.attendanceData[:].curso''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  List? asistencias(dynamic response) => getJsonField(
        response,
        r'''$.attendanceData[:].asistencias''',
        true,
      ) as List?;
  List<String>? fecha(dynamic response) => (getJsonField(
        response,
        r'''$.attendanceData[:].asistencias[:].fecha''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  List<String>? dia(dynamic response) => (getJsonField(
        response,
        r'''$.attendanceData[:].asistencias[:].dia''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  List<String>? estado(dynamic response) => (getJsonField(
        response,
        r'''$.attendanceData[:].asistencias[:].estado''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
}

class ScheduleCall {
  Future<ApiCallResponse> call({
    String? authToken = '',
  }) async {
    final baseUrl = ApiGroup.getBaseUrl(
      authToken: authToken,
    );

    return ApiManager.instance.makeApiCall(
      callName: 'Schedule',
      apiUrl: '${baseUrl}/api/v1/schedule',
      callType: ApiCallType.GET,
      headers: {
        'Authorization': 'Bearer ${authToken}',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }

  List? schedule(dynamic response) => getJsonField(
        response,
        r'''$.schedule''',
        true,
      ) as List?;
  String? userCode(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.userCode''',
      ));
}

class AttendanceCall {
  Future<ApiCallResponse> call({
    String? authToken = '',
  }) async {
    final baseUrl = ApiGroup.getBaseUrl(
      authToken: authToken,
    );

    return ApiManager.instance.makeApiCall(
      callName: 'Attendance',
      apiUrl: '${baseUrl}/api/v1/attendance',
      callType: ApiCallType.GET,
      headers: {
        'Authorization': 'Bearer ${authToken}',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }

  List? attendance(dynamic response) => getJsonField(
        response,
        r'''$.attendanceData''',
        true,
      ) as List?;
  List<String>? curso(dynamic response) => (getJsonField(
        response,
        r'''$.attendanceData[:].curso''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  List? asistencias(dynamic response) => getJsonField(
        response,
        r'''$.attendanceData[:].asistencias''',
        true,
      ) as List?;
  List<String>? fecha(dynamic response) => (getJsonField(
        response,
        r'''$.attendanceData[:].asistencias[:].fecha''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  List<String>? dia(dynamic response) => (getJsonField(
        response,
        r'''$.attendanceData[:].asistencias[:].dia''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
  List<String>? estado(dynamic response) => (getJsonField(
        response,
        r'''$.attendanceData[:].asistencias[:].estado''',
        true,
      ) as List?)
          ?.withoutNulls
          .map((x) => castToType<String>(x))
          .withoutNulls
          .toList();
}

class AllJustificationCall {
  Future<ApiCallResponse> call({
    String? authToken = '',
  }) async {
    final baseUrl = ApiGroup.getBaseUrl(
      authToken: authToken,
    );

    return ApiManager.instance.makeApiCall(
      callName: 'All Justification',
      apiUrl: '${baseUrl}/api/v1/justifications/history',
      callType: ApiCallType.GET,
      headers: {
        'Authorization': 'Bearer ${authToken}',
      },
      params: {},
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }

  List? justification(dynamic response) => getJsonField(
        response,
        r'''$.justifications''',
        true,
      ) as List?;
}

class JustificactionCall {
  Future<ApiCallResponse> call({
    String? date = '',
    String? reason = '',
    String? description = '',
    String? attachment = '',
    String? authToken = '',
  }) async {
    final baseUrl = ApiGroup.getBaseUrl(
      authToken: authToken,
    );

    return ApiManager.instance.makeApiCall(
      callName: 'Justificaction',
      apiUrl: '${baseUrl}/api/v1/justifications/submit',
      callType: ApiCallType.POST,
      headers: {
        'Authorization': 'Bearer ${authToken}',
      },
      params: {
        'date': date,
        'reason': reason,
        'description': description,
        'attachment': attachment,
      },
      bodyType: BodyType.MULTIPART,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }

  String? message(dynamic response) => castToType<String>(getJsonField(
        response,
        r'''$.message''',
      ));
}

/// End API Group Code

class ApiPagingParams {
  int nextPageNumber = 0;
  int numItems = 0;
  dynamic lastResponse;

  ApiPagingParams({
    required this.nextPageNumber,
    required this.numItems,
    required this.lastResponse,
  });

  @override
  String toString() =>
      'PagingParams(nextPageNumber: $nextPageNumber, numItems: $numItems, lastResponse: $lastResponse,)';
}

String _toEncodable(dynamic item) {
  return item;
}

String _serializeList(List? list) {
  list ??= <String>[];
  try {
    return json.encode(list, toEncodable: _toEncodable);
  } catch (_) {
    if (kDebugMode) {
      print("List serialization failed. Returning empty list.");
    }
    return '[]';
  }
}

String _serializeJson(dynamic jsonVar, [bool isList = false]) {
  jsonVar ??= (isList ? [] : {});
  try {
    return json.encode(jsonVar, toEncodable: _toEncodable);
  } catch (_) {
    if (kDebugMode) {
      print("Json serialization failed. Returning empty json.");
    }
    return isList ? '[]' : '{}';
  }
}

String? escapeStringForJson(String? input) {
  if (input == null) {
    return null;
  }
  return input
      .replaceAll('\\', '\\\\')
      .replaceAll('"', '\\"')
      .replaceAll('\n', '\\n')
      .replaceAll('\t', '\\t');
}
