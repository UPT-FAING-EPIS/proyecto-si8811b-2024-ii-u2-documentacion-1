import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'pagina_principal_model.dart';
export 'pagina_principal_model.dart';

class PaginaPrincipalWidget extends StatefulWidget {
  /// 1. Estructura General
  /// Usa un Column Widget como contenedor principal para alinear todos los
  /// elementos verticalmente.
  /// Dentro del Column, organiza la pantalla en tres secciones principales:
  /// Banner Superior.
  /// Cuerpo con Información y Botones.
  /// Botón Flotante para el Perfil.
  /// 2. Sección: Banner Superior
  /// Widget: Container.
  /// Propiedades:
  /// Altura: Aproximadamente el 20% de la pantalla.
  /// Fondo: Degradado (ejemplo: azul a blanco, o según el tema de tu
  /// aplicación).
  /// Contenido:
  /// Dentro del Container, usa un Column para alinear los textos:
  /// Texto 1 (Bienvenida):
  /// Widget: Text.
  /// Texto: "¡Bienvenido, [Nombre del Usuario]!" (donde el nombre puede ser una
  /// variable de usuario).
  /// Estilo: Fuente grande, bold, color blanco.
  /// Texto 2 (Subtítulo):
  /// Widget: Text.
  /// Texto: "¡Gestiona tu tiempo y tus responsabilidades de manera eficiente!"
  /// Estilo: Fuente mediana, color blanco/gris claro.
  /// 3. Sección: Cuerpo con Información
  /// Widget: Column.
  /// Propiedades:
  /// Usa Padding para dar espacio alrededor del contenido.
  /// Contenido:
  /// Texto Informativo:
  ///
  /// Widget: Text.
  /// Texto:
  /// plaintext
  /// Copiar código
  /// "La organización es clave para el éxito. Con nuestra plataforma, puedes
  /// consultar tu horario actualizado, revisar tu historial de asistencias y
  /// gestionar cualquier justificación necesaria. Así, puedes mantener un
  /// control total de tus actividades y optimizar tu tiempo de manera
  /// efectiva."
  /// Estilo: Fuente regular, tamaño mediano, alineación centrada.
  /// Coloca un margen superior e inferior para espaciarlo de los botones.
  /// Botones Principales:
  ///
  /// Widget: Row o Column, dependiendo de si deseas los botones en línea o en
  /// una lista vertical.
  /// Botón 1: Ver Horario
  /// Widget: Button.
  /// Texto: "Ver Horario".
  /// Ícono: calendar.
  /// Color de Fondo: Azul claro.
  /// Acción: Navega a la pantalla de horario.
  /// Botón 2: Ver Asistencias
  /// Widget: Button.
  /// Texto: "Ver Asistencias".
  /// Ícono: checklist.
  /// Color de Fondo: Verde.
  /// Acción: Navega a la pantalla de asistencias.
  /// Botón 3: Justificaciones
  /// Widget: Button.
  /// Texto: "Justificaciones".
  /// Ícono: folder.
  /// Color de Fondo: Amarillo suave.
  /// Acción: Navega a la pantalla de justificaciones.
  /// 4. Botón Flotante: Ver Perfil
  /// Widget: FloatingActionButton.
  /// Posición: Esquina inferior derecha (usando el posicionamiento flotante de
  /// FlutterFlow).
  /// Propiedades:
  /// Ícono: user o un avatar predeterminado.
  /// Fondo: Gris claro con sombra.
  /// Acción: Navegar a la pantalla de perfil.
  /// Nota: Este botón debe estar disponible globalmente si es posible.
  /// 5. Pie de Página (Opcional)
  /// Widget: Text.
  /// Texto: "Diseñado para ayudarte a organizar tu tiempo. ¡Tu éxito es nuestra
  /// prioridad!"
  /// Estilo: Fuente pequeña, color gris.
  /// Posición: Parte inferior centrada de la pantalla (dentro de un Padding).
  /// Implementación en FlutterFlow
  /// Paso 1: Usa un Column Widget para estructurar toda la pantalla.
  ///
  /// Paso 2: Agrega un Container en la parte superior para el banner,
  /// configurando un fondo degradado y texto dentro.
  ///
  /// Paso 3: En el cuerpo principal (otro Column):
  ///
  /// Coloca un texto informativo con padding.
  /// Agrega los tres botones principales (dentro de un Column o Row según el
  /// diseño).
  /// Paso 4: Usa un FloatingActionButton para el botón de perfil,
  /// configurándolo para navegar a la página correspondiente.
  ///
  /// Paso 5: Opcionalmente, agrega un pie de página con texto breve.
  ///
  /// Ejemplo de Texto Listo para Copiar:
  /// Banner de Bienvenida
  /// "¡Bienvenido, [Nombre del Usuario]!"
  /// "¡Gestiona tu tiempo y tus responsabilidades de manera eficiente!"
  /// Texto Informativo
  /// "La organización es clave para el éxito. Con nuestra plataforma, puedes
  /// consultar tu horario actualizado, revisar tu historial de asistencias y
  /// gestionar cualquier justificación necesaria. Así, puedes mantener un
  /// control total de tus actividades y optimizar tu tiempo de manera
  /// efectiva."
  /// Botones
  /// "Ver Horario"
  /// "Ver Asistencias"
  /// "Justificaciones"
  /// Pie de Página
  /// "Diseñado para ayudarte a organizar tu tiempo. ¡Tu éxito es nuestra
  /// prioridad!"
  /// Agregale un boton en la esquina inferior  que sera destinado a el perfil
  /// que tena un logo de perfil
  const PaginaPrincipalWidget({super.key});

  @override
  State<PaginaPrincipalWidget> createState() => _PaginaPrincipalWidgetState();
}

class _PaginaPrincipalWidgetState extends State<PaginaPrincipalWidget> {
  late PaginaPrincipalModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => PaginaPrincipalModel());
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    context.watch<FFAppState>();

    return GestureDetector(
      onTap: () {
        FocusScope.of(context).unfocus();
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        key: scaffoldKey,
        backgroundColor: FlutterFlowTheme.of(context).primaryBackground,
        body: Container(
          width: MediaQuery.sizeOf(context).width * 1.0,
          height: MediaQuery.sizeOf(context).height * 1.0,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFF1A237E), Color(0xFF3949AB)],
              stops: [0.0, 1.0],
              begin: AlignmentDirectional(0.0, -1.0),
              end: AlignmentDirectional(0, 1.0),
            ),
          ),
          child: Padding(
            padding: EdgeInsetsDirectional.fromSTEB(24.0, 24.0, 24.0, 24.0),
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: MediaQuery.sizeOf(context).width * 1.0,
                    height: 200.0,
                    child: Padding(
                      padding: EdgeInsetsDirectional.fromSTEB(
                          24.0, 24.0, 24.0, 24.0),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            '¡Bienvenido ',
                            style: FlutterFlowTheme.of(context)
                                .headlineMedium
                                .override(
                                  fontFamily: 'Inter Tight',
                                  color: FlutterFlowTheme.of(context).info,
                                  letterSpacing: 0.0,
                                  fontWeight: FontWeight.bold,
                                ),
                          ),
                          Text(
                            FFAppState().userName,
                            style: FlutterFlowTheme.of(context)
                                .headlineMedium
                                .override(
                                  fontFamily: 'Inter Tight',
                                  letterSpacing: 0.0,
                                ),
                          ),
                          Text(
                            '¡Gestiona tu tiempo y tus responsabilidades de manera eficiente!',
                            style:
                                FlutterFlowTheme.of(context).bodyLarge.override(
                                      fontFamily: 'Inter',
                                      color: Color(0xFFE0E0E0),
                                      letterSpacing: 0.0,
                                    ),
                          ),
                        ].divide(SizedBox(height: 8.0)),
                      ),
                    ),
                  ),
                  Material(
                    color: Colors.transparent,
                    elevation: 4.0,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16.0),
                    ),
                    child: Container(
                      width: MediaQuery.sizeOf(context).width * 1.0,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(16.0),
                      ),
                      child: Padding(
                        padding: EdgeInsetsDirectional.fromSTEB(
                            24.0, 24.0, 24.0, 24.0),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Text(
                              'La organización es clave para el éxito. Con nuestra plataforma, puedes consultar tu horario actualizado, revisar tu historial de asistencias y gestionar cualquier justificación necesaria.',
                              textAlign: TextAlign.center,
                              style: FlutterFlowTheme.of(context)
                                  .bodyMedium
                                  .override(
                                    fontFamily: 'Inter',
                                    letterSpacing: 0.0,
                                  ),
                            ),
                            Container(
                              width: MediaQuery.sizeOf(context).width * 1.0,
                              decoration: BoxDecoration(
                                color: Color(0xFFE3F2FD),
                                borderRadius: BorderRadius.circular(12.0),
                              ),
                              child: Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    16.0, 16.0, 16.0, 16.0),
                                child: InkWell(
                                  splashColor: Colors.transparent,
                                  focusColor: Colors.transparent,
                                  hoverColor: Colors.transparent,
                                  highlightColor: Colors.transparent,
                                  onTap: () async {
                                    _model.resultado =
                                        await ApiGroup.scheduleCall.call(
                                      authToken: FFAppState().authToken,
                                    );

                                    if ((_model.resultado?.succeeded ?? true)) {
                                      FFAppState().horarioList = getJsonField(
                                        (_model.resultado?.jsonBody ?? ''),
                                        r'''$.schedule''',
                                        true,
                                      )!
                                          .toList()
                                          .cast<dynamic>();
                                      safeSetState(() {});

                                      context.pushNamed('PaginaHorario');
                                    }

                                    safeSetState(() {});
                                  },
                                  child: Row(
                                    mainAxisSize: MainAxisSize.max,
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Row(
                                        mainAxisSize: MainAxisSize.max,
                                        children: [
                                          Icon(
                                            Icons.calendar_today,
                                            color: Color(0xFF1565C0),
                                            size: 24.0,
                                          ),
                                          Text(
                                            'Ver Horario',
                                            style: FlutterFlowTheme.of(context)
                                                .bodyLarge
                                                .override(
                                                  fontFamily: 'Inter',
                                                  color: Color(0xFF1565C0),
                                                  letterSpacing: 0.0,
                                                ),
                                          ),
                                        ].divide(SizedBox(width: 12.0)),
                                      ),
                                      Icon(
                                        Icons.chevron_right,
                                        color: Color(0xFF1565C0),
                                        size: 24.0,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            Container(
                              width: MediaQuery.sizeOf(context).width * 1.0,
                              decoration: BoxDecoration(
                                color: Color(0xFFE8F5E9),
                                borderRadius: BorderRadius.circular(12.0),
                              ),
                              child: Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    16.0, 16.0, 16.0, 16.0),
                                child: InkWell(
                                  splashColor: Colors.transparent,
                                  focusColor: Colors.transparent,
                                  hoverColor: Colors.transparent,
                                  highlightColor: Colors.transparent,
                                  onTap: () async {
                                    _model.apiResulttyb =
                                        await ApiGroup.attendanceCall.call(
                                      authToken: FFAppState().authToken,
                                    );

                                    if ((_model.apiResulttyb?.succeeded ??
                                        true)) {
                                      FFAppState().asistenciasList =
                                          getJsonField(
                                        (_model.apiResulttyb?.jsonBody ?? ''),
                                        r'''$.attendanceData''',
                                        true,
                                      )!
                                              .toList()
                                              .cast<dynamic>();
                                      safeSetState(() {});

                                      context.pushNamed('Asistencias');
                                    }

                                    safeSetState(() {});
                                  },
                                  child: Row(
                                    mainAxisSize: MainAxisSize.max,
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Row(
                                        mainAxisSize: MainAxisSize.max,
                                        children: [
                                          Icon(
                                            Icons.check_circle,
                                            color: Color(0xFF2E7D32),
                                            size: 24.0,
                                          ),
                                          Text(
                                            'Ver Asistencias',
                                            style: FlutterFlowTheme.of(context)
                                                .bodyLarge
                                                .override(
                                                  fontFamily: 'Inter',
                                                  color: Color(0xFF2E7D32),
                                                  letterSpacing: 0.0,
                                                ),
                                          ),
                                        ].divide(SizedBox(width: 12.0)),
                                      ),
                                      Icon(
                                        Icons.chevron_right,
                                        color: Color(0xFF2E7D32),
                                        size: 24.0,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            Container(
                              width: MediaQuery.sizeOf(context).width * 1.0,
                              decoration: BoxDecoration(
                                color: Color(0xFFFFF8E1),
                                borderRadius: BorderRadius.circular(12.0),
                              ),
                              child: Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    16.0, 16.0, 16.0, 16.0),
                                child: InkWell(
                                  splashColor: Colors.transparent,
                                  focusColor: Colors.transparent,
                                  hoverColor: Colors.transparent,
                                  highlightColor: Colors.transparent,
                                  onTap: () async {
                                    _model.token = await ApiGroup
                                        .allJustificationCall
                                        .call(
                                      authToken: FFAppState().authToken,
                                    );

                                    if ((_model.token?.succeeded ?? true)) {
                                      FFAppState().justificacionesList =
                                          getJsonField(
                                        (_model.token?.jsonBody ?? ''),
                                        r'''$.justifications''',
                                        true,
                                      )!
                                              .toList()
                                              .cast<dynamic>();
                                      safeSetState(() {});

                                      context.pushNamed('Justificaciones');
                                    }

                                    safeSetState(() {});
                                  },
                                  child: Row(
                                    mainAxisSize: MainAxisSize.max,
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Row(
                                        mainAxisSize: MainAxisSize.max,
                                        children: [
                                          Icon(
                                            Icons.folder,
                                            color: Color(0xFFFF6F00),
                                            size: 24.0,
                                          ),
                                          Text(
                                            'Justificaciones',
                                            style: FlutterFlowTheme.of(context)
                                                .bodyLarge
                                                .override(
                                                  fontFamily: 'Inter',
                                                  color: Color(0xFFFF6F00),
                                                  letterSpacing: 0.0,
                                                ),
                                          ),
                                        ].divide(SizedBox(width: 12.0)),
                                      ),
                                      Icon(
                                        Icons.chevron_right,
                                        color: Color(0xFFFF6F00),
                                        size: 24.0,
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ].divide(SizedBox(height: 16.0)),
                        ),
                      ),
                    ),
                  ),
                  Text(
                    'Diseñado para ayudarte a organizar tu tiempo. ¡Tu éxito es nuestra prioridad!',
                    textAlign: TextAlign.center,
                    style: FlutterFlowTheme.of(context).bodySmall.override(
                          fontFamily: 'Inter',
                          color: Color(0xFFE0E0E0),
                          letterSpacing: 0.0,
                        ),
                  ),
                  Container(
                    width: MediaQuery.sizeOf(context).width * 1.0,
                    height: 80.0,
                    child: Padding(
                      padding:
                          EdgeInsetsDirectional.fromSTEB(0.0, 24.0, 0.0, 24.0),
                      child: Row(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          Material(
                            color: Colors.transparent,
                            elevation: 4.0,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(30.0),
                            ),
                            child: Container(
                              width: 60.0,
                              height: 60.0,
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(30.0),
                              ),
                              child: InkWell(
                                splashColor: Colors.transparent,
                                focusColor: Colors.transparent,
                                hoverColor: Colors.transparent,
                                highlightColor: Colors.transparent,
                                onTap: () async {
                                  _model.result =
                                      await ApiGroup.defaultUserCall.call(
                                    authToken: FFAppState().authToken,
                                  );

                                  if ((_model.result?.succeeded ?? true)) {
                                    FFAppState().userName = getJsonField(
                                      (_model.result?.jsonBody ?? ''),
                                      r'''$.name''',
                                    ).toString();
                                    FFAppState().userEmail = getJsonField(
                                      (_model.result?.jsonBody ?? ''),
                                      r'''$.email''',
                                    ).toString();
                                    safeSetState(() {});

                                    context.pushNamed('PaginaUsuario');
                                  }

                                  safeSetState(() {});
                                },
                                child: Icon(
                                  Icons.person,
                                  color: FlutterFlowTheme.of(context).primary,
                                  size: 30.0,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ].divide(SizedBox(height: 24.0)),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
