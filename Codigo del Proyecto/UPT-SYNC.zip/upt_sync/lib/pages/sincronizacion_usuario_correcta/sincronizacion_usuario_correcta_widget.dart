import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'sincronizacion_usuario_correcta_model.dart';
export 'sincronizacion_usuario_correcta_model.dart';

class SincronizacionUsuarioCorrectaWidget extends StatefulWidget {
  /// Creameuna alerta positiva que diga Sincronizacion de Datos de Usuarios
  /// Correcta
  const SincronizacionUsuarioCorrectaWidget({super.key});

  @override
  State<SincronizacionUsuarioCorrectaWidget> createState() =>
      _SincronizacionUsuarioCorrectaWidgetState();
}

class _SincronizacionUsuarioCorrectaWidgetState
    extends State<SincronizacionUsuarioCorrectaWidget> {
  late SincronizacionUsuarioCorrectaModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => SincronizacionUsuarioCorrectaModel());
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsetsDirectional.fromSTEB(16.0, 16.0, 16.0, 16.0),
      child: Container(
        width: double.infinity,
        decoration: BoxDecoration(
          color: FlutterFlowTheme.of(context).secondaryBackground,
          borderRadius: BorderRadius.circular(12.0),
          border: Border.all(
            color: FlutterFlowTheme.of(context).success,
            width: 2.0,
          ),
        ),
        child: Padding(
          padding: EdgeInsets.all(12.0),
          child: Row(
            mainAxisSize: MainAxisSize.max,
            children: [
              Icon(
                Icons.check_circle_rounded,
                color: FlutterFlowTheme.of(context).success,
                size: 24.0,
              ),
              Expanded(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      'Sincronización Exitosa',
                      style: FlutterFlowTheme.of(context).titleMedium.override(
                            fontFamily: 'Inter Tight',
                            color: FlutterFlowTheme.of(context).success,
                            letterSpacing: 0.0,
                          ),
                    ),
                    Text(
                      'Los datos del usuario han sido sincronizados correctamente.',
                      style: FlutterFlowTheme.of(context).bodyMedium.override(
                            fontFamily: 'Inter',
                            color: FlutterFlowTheme.of(context).secondaryText,
                            letterSpacing: 0.0,
                          ),
                    ),
                  ],
                ),
              ),
            ].divide(SizedBox(width: 12.0)),
          ),
        ),
      ),
    );
  }
}
