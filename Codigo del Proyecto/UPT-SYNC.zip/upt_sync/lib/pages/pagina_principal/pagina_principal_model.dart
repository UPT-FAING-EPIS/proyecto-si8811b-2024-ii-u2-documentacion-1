import '/backend/api_requests/api_calls.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'pagina_principal_widget.dart' show PaginaPrincipalWidget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class PaginaPrincipalModel extends FlutterFlowModel<PaginaPrincipalWidget> {
  ///  State fields for stateful widgets in this page.

  // Stores action output result for [Backend Call - API (Schedule)] action in Row widget.
  ApiCallResponse? resultado;
  // Stores action output result for [Backend Call - API (Attendance)] action in Row widget.
  ApiCallResponse? apiResulttyb;
  // Stores action output result for [Backend Call - API (All Justification)] action in Row widget.
  ApiCallResponse? token;
  // Stores action output result for [Backend Call - API (Default User)] action in Icon widget.
  ApiCallResponse? result;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
