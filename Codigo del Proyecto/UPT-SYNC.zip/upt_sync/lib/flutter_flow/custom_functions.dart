import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'lat_lng.dart';
import 'place.dart';
import 'uploaded_file.dart';

List<String>? filterDaysWithSchedules(List<dynamic>? schedule) {
  // Verifica que schedule no sea nulo y tenga elementos
  if (schedule == null || schedule.isEmpty) {
    return [];
  }

  // Iterar sobre los elementos de la lista y procesar cada mapa
  List<String> result = [];
  for (var item in schedule) {
    // Convertir cada elemento en un mapa
    final Map<String, dynamic> scheduleMap = Map<String, dynamic>.from(item);

    // Filtrar días con horarios no vacíos
    result.addAll(scheduleMap.entries
        .where((entry) => (entry.value as List).isNotEmpty)
        .map((entry) => jsonEncode({'day': entry.key, 'times': entry.value}))
        .toList());
  }

  return result;
}

DateTime stringToDate(String value) {
  try {
    return DateTime.parse(value);
  } catch (e) {
    return DateTime.now(); // Valor por defecto si hay error en el parsing
  }
}
