package com.mycompany.uptsync

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
